/*--------------------- Copyright (c) 2023 -----------------------
[Master Javascript]
Personal Credit
Version: 1.0.0
-------------------------------------------------------------------*/
(function($){
    "use strict";
  
    // Ready Function
    jQuery(document).ready(function($){
        var $this = $(window);

        // Menu toggle
        $('.credit_menu_icon').on('click',function () {
            $('.credit_menu>ul').toggleClass('clicked');
        });
        
        // Fixed Header
        $(window).scroll(function(){
            if ($(window).scrollTop() >= 200) {
                $('.credit_header_wrap').addClass('fixed');
            }
            else {
                $('.credit_header_wrap').removeClass('fixed');
            }
        });






        
        // AOS Animation
        AOS.init({
            duration: 1200,
        })

   

    });
})();



// Filter
    $(document).ready(function(){
        $(".openFilter").click(function(){
          $(".hideFilter").addClass("active");
        
        });
        $(".hideMe").click(function(){
            $(".hideFilter").removeClass("active");
         
          });
      });





      $( '.dropDown' ).click(function() {
        $( '.megaMenu' ).toggleClass('active');
        });
        
        /// this activate the click menu ON and hide the menu ///
        
        $( '.menu li' ).click(function() {
        $( '.menu' ).toggleClass('active');
        });